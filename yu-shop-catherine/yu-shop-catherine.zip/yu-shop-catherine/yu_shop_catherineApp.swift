//
//  yu_shop_catherineApp.swift
//  yu-shop-catherine
//
//  Created by adobada on 8/19/22.
//

import SwiftUI

@main
struct yu_shop_catherineApp: App {
  var body: some Scene {
    WindowGroup {
      WelcomeView()
    }
  }
}
